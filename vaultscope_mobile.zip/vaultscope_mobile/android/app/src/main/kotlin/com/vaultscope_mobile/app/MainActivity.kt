package com.vaultscope_mobile.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
